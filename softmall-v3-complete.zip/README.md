# Softmall SaaS v3

Full-stack SaaS foundation for Web + Android + iOS.

## Included
- Multi-tenant users and organizations
- JWT authentication and protected API routes
- Automatic organization onboarding
- Product CRUD + stock
- Customers
- Orders + stock deduction
- Analytics
- Plans and subscription records
- Billing intent/transaction ledger (provider-neutral; payment provider keys required)
- Admin overview
- Web login/signup/admin screens
- Mobile dashboard
- PostgreSQL + Prisma
- Docker

## Run
cp .env.example .env
docker compose up -d postgres
pnpm install
pnpm db:generate
pnpm db:migrate
pnpm db:seed
pnpm dev

API: http://localhost:4000
Web: http://localhost:3000

For production payments, configure Paystack or Stripe credentials and implement their checkout/webhook handlers before activating paid subscriptions.
