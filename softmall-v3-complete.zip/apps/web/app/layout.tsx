import './globals.css';
export const metadata={title:'Softmall',description:'Modern SaaS platform'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
