import { Body, Controller, Delete, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { IsInt, IsOptional, IsString, Min } from 'class-validator';
import { SaaSService } from './saas.service';

class ProductDto {
  @IsString() organizationId!: string;
  @IsString() name!: string;
  @IsString() sku!: string;
  @IsOptional() @IsString() description?: string;
  @IsInt() @Min(0) price!: number;
  @IsInt() @Min(0) stock!: number;
}
class CustomerDto {
  @IsString() organizationId!: string;
  @IsString() name!: string;
  @IsOptional() @IsString() email?: string;
  @IsOptional() @IsString() phone?: string;
  @IsOptional() @IsString() address?: string;
}
class OrderDto {
  @IsString() organizationId!: string;
  @IsOptional() @IsString() customerId?: string;
  items!: { productId: string; quantity: number }[];
}
@Controller('saas')
export class SaaSController {
  constructor(private readonly service: SaaSService) {}
  @Get('products') products(@Query('organizationId') id: string) { return this.service.products(id); }
  @Post('products') createProduct(@Body() dto: ProductDto) { return this.service.createProduct(dto); }
  @Patch('products/:id') updateProduct(@Param('id') id:string,@Body() dto:Partial<ProductDto>) { return this.service.updateProduct(id,dto); }
  @Delete('products/:id') deleteProduct(@Param('id') id:string) { return this.service.deleteProduct(id); }

  @Get('customers') customers(@Query('organizationId') id: string) { return this.service.customers(id); }
  @Post('customers') createCustomer(@Body() dto: CustomerDto) { return this.service.createCustomer(dto); }

  @Get('orders') orders(@Query('organizationId') id: string) { return this.service.orders(id); }
  @Post('orders') createOrder(@Body() dto: OrderDto) { return this.service.createOrder(dto); }
  @Patch('orders/:id/status') status(@Param('id') id:string,@Body('status') status:string) { return this.service.updateOrderStatus(id,status); }

  @Get('analytics') analytics(@Query('organizationId') id: string) { return this.service.analytics(id); }
}
