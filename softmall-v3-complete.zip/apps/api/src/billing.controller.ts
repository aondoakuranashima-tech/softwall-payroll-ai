import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from './auth.guard';
import { BillingService } from './billing.service';
@Controller('billing')
@UseGuards(AuthGuard)
export class BillingController{
 constructor(private billing:BillingService){}
 @Get('plans') plans(){return this.billing.plans();}
 @Get('subscription') subscription(@Req() req:any){return this.billing.subscription(req.user.organizationId);}
 @Post('subscribe') subscribe(@Req() req:any,@Body('planId') planId:string){return this.billing.subscribe(req.user.organizationId,req.user.sub,planId);}
 @Get('transactions') transactions(@Req() req:any){return this.billing.transactions(req.user.organizationId);}
}