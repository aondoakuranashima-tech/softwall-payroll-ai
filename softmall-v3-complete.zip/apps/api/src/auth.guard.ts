import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
@Injectable()
export class AuthGuard implements CanActivate {
 constructor(private jwt:JwtService){}
 canActivate(ctx:ExecutionContext){
  const req=ctx.switchToHttp().getRequest();
  const token=req.headers.authorization?.replace(/^Bearer\s+/,'');
  if(!token) throw new UnauthorizedException('Bearer token required');
  try{req.user=this.jwt.verify(token);return true}catch{throw new UnauthorizedException('Invalid or expired token')}
 }
}