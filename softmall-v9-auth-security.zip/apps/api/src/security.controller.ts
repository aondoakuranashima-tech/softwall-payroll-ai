import {Body,Controller,Post,Query} from '@nestjs/common';import {SecurityService} from './security.service';
@Controller('security') export class SecurityController{
 constructor(private readonly security:SecurityService){}
 @Post('verify-email') verify(@Query('token') token:string){return this.security.verify(token)}
 @Post('request-reset') async request(@Body('email') email:string){const token=await this.security.issueReset(email);return {ok:true,resetToken:token}}
 @Post('reset-password') reset(@Body('token') token:string,@Body('password') password:string){if(!password||password.length<8)throw new Error('Password must be at least 8 characters');return this.security.reset(token,password)}
}