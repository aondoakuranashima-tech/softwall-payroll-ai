import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from './auth.guard';
import { db } from './prisma';
@Controller('billing')
@UseGuards(AuthGuard)
export class BillingController{
 @Get('plans') plans(){return db.plan.findMany({orderBy:{price:'asc'}});}
 @Get('subscription') subscription(@Req() req:any){return db.subscription.findUnique({where:{organizationId:req.user.organizationId},include:{plan:true}});}
 @Get('transactions') transactions(@Req() req:any){return db.transaction.findMany({where:{organizationId:req.user.organizationId},orderBy:{createdAt:'desc'}});}
}