 'use client';
import Link from 'next/link';
import {usePathname,useRouter} from 'next/navigation';
import {useEffect,useState} from 'react';
const nav=[['/','Dashboard'],['/products','Products'],['/customers','Customers'],['/orders','Orders'],['/billing','Billing'],['/admin','Admin']];
export default function AppShell({children}:{children:React.ReactNode}){
 const path=usePathname(),router=useRouter(); const [user,setUser]=useState<any>(null);
 useEffect(()=>{const t=localStorage.getItem('softmall_token');if(!t){router.replace('/login');return}try{const p=JSON.parse(atob(t.split('.')[1].replace(/-/g,'+').replace(/_/g,'/')));setUser(p)}catch{localStorage.removeItem('softmall_token');router.replace('/login')}},[router]);
 if(!user)return <div className="loading">Loading Softmall…</div>;
 return <main className="app"><aside className="sidebar"><div className="brand">SOFTMALL<span>•</span></div><div className="workspace">Business workspace</div><nav>{nav.map(([href,label])=><Link key={href} href={href} className={path===href?'active':''}>{label}</Link>)}</nav><button className="logout" onClick={()=>{localStorage.removeItem('softmall_token');router.replace('/login')}}>Sign out</button></aside><section className="shell"><header className="topbar"><input className="search" placeholder="Search Softmall…" /><div className="userchip"><span>{user.email?.slice(0,1).toUpperCase()}</span>{user.email}</div></header>{children}</section></main>
}