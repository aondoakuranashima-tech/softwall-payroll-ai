
## Real payments
Paystack:
- `POST /payments/paystack/checkout` with `{ "planId": "..." }`
- `POST /payments/paystack/verify` with `{ "reference": "..." }`
- `POST /payments/paystack/webhook`
- Webhook signature is verified with `x-paystack-signature`.
- Paid transactions activate the matching subscription idempotently.

Stripe:
- `POST /payments/stripe/checkout` with `{ "planId": "..." }`
- `POST /payments/stripe/webhook`
- Webhook signature is verified with `stripe-signature`.
- Checkout completion activates the matching subscription idempotently.

Never expose secret keys in Web/mobile code. Use test keys first, then production keys after end-to-end testing.

## Payments
Set `PAYSTACK_SECRET_KEY`, `PAYSTACK_PUBLIC_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, and `APP_URL`.
Paystack checkout is server-initialized and confirmed by webhook/verification. Stripe uses Checkout Sessions and signed webhooks.
Configure webhook endpoints:
- `POST /payments/paystack/webhook`
- `POST /payments/stripe/webhook`
