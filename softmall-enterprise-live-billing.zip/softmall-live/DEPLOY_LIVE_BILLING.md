# Live billing launch runbook

## Provider configuration
Set these secrets in the API deployment environment, never in Git:
- DATABASE_URL
- JWT_SECRET
- APP_URL
- CORS_ORIGINS
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- PAYSTACK_SECRET_KEY
- PAYSTACK_PUBLIC_KEY

## Stripe
Create a webhook endpoint at:
`https://YOUR_API_DOMAIN/payments/stripe/webhook`
Subscribe to:
- checkout.session.completed
- customer.subscription.created
- customer.subscription.updated
- customer.subscription.deleted
- invoice.paid
- invoice.payment_failed

## Paystack
Create a webhook endpoint at:
`https://YOUR_API_DOMAIN/payments/paystack/webhook`
Use the live secret key. Paystack signs webhook requests with `x-paystack-signature`.

## Database
Run:
`pnpm --filter @softmall/database prisma generate`
`pnpm --filter @softmall/database prisma migrate deploy`
`pnpm --filter @softmall/database seed`

## Production verification
- Use HTTPS only.
- Confirm CORS_ORIGINS is the exact web origin.
- Test a small live transaction before launch.
- Confirm the webhook changes transaction status and subscription state.
- Replay a webhook and confirm it is deduplicated.
- Test failed renewal and cancellation.
- Verify billing portal access.
- Never activate a paid plan from a client redirect alone; activation occurs from verified provider events.
