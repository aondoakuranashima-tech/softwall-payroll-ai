# Softmall enterprise billing

Implemented in this release:
- Stripe Checkout in subscription mode with recurring prices.
- Stripe customer creation and billing portal.
- Stripe subscription lifecycle synchronization: created, updated, canceled, invoice paid, invoice payment failed.
- Paystack initialization and verification.
- Paystack webhook signature verification.
- Webhook idempotency using a database-backed WebhookEvent table.
- Amount and currency reconciliation before activation.
- Subscription provider/customer identifiers and renewal/cancellation state.
- Live billing UI with provider selection and billing portal.
- Raw-body webhook verification support.
- Strict CORS and global request validation.

Production setup:
1. Set real STRIPE_SECRET_KEY and STRIPE_WEBHOOK_SECRET.
2. Set real PAYSTACK_SECRET_KEY.
3. Create Stripe products/prices or allow Softmall to create recurring prices as checkout sessions do here.
4. Configure Stripe webhook endpoint: POST /payments/stripe/webhook for checkout.session.completed, customer.subscription.created, customer.subscription.updated, customer.subscription.deleted, invoice.paid, invoice.payment_failed.
5. Configure Paystack webhook endpoint: POST /payments/paystack/webhook.
6. Run Prisma migration and generate the client.
7. Seed production Plan rows with accurate NGN prices/features.
8. Configure CORS_ORIGINS to the exact production web origin.
9. Never commit live keys. Store them in the hosting provider's secret manager.

Important: this repository contains production billing code, but it cannot become actually live until real provider credentials, webhook URLs, PostgreSQL, DNS and deployment infrastructure are configured in the owner's accounts.
