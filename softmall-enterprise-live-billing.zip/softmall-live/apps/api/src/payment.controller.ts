import {Body,Controller,Get,Headers,Param,Post,Req,UseGuards} from '@nestjs/common';import {AuthGuard} from './auth.guard';import {PaymentService} from './payment.service';import {Roles} from './roles.decorator';import {RolesGuard} from './roles.guard';import {RateLimitGuard} from './rate-limit.guard';
@Controller('payments') export class PaymentController{constructor(private readonly p:PaymentService){}
 @UseGuards(AuthGuard,RolesGuard,RateLimitGuard) @Roles('ADMIN','OWNER') @Post('paystack/checkout') paystack(@Req() r:any,@Body('planId') planId:string){return this.p.paystackCheckout(r.user.sub,r.user.organizationId,planId)}
 @UseGuards(AuthGuard,RolesGuard,RateLimitGuard) @Roles('ADMIN','OWNER') @Post('stripe/checkout') stripe(@Req() r:any,@Body('planId') planId:string){return this.p.stripeCheckout(r.user.sub,r.user.organizationId,planId)}
 @UseGuards(AuthGuard) @Get('paystack/verify/:reference') verify(@Param('reference') ref:string){return this.p.verifyPaystack(ref)}
 @Post('paystack/webhook') paystackWebhook(@Req() r:any,@Headers('x-paystack-signature') sig:string){return this.p.handlePaystackWebhook(r.rawBody,sig)}
 @Post('stripe/webhook') stripeWebhook(@Req() r:any,@Headers('stripe-signature') sig:string){return this.p.handleStripeWebhook(r.rawBody,sig)}
 @UseGuards(AuthGuard,RolesGuard) @Roles('ADMIN','OWNER') @Post('portal') portal(@Req() r:any){return this.p.portal(r.user.organizationId)}
}
