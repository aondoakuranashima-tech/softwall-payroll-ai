import { PrismaClient } from '@prisma/client';
const db=new PrismaClient();
async function main(){
 await db.plan.createMany({data:[
  {name:'Free',price:0,billingCycle:'month',features:['Dashboard','50 products','Basic analytics'],providerPlanCode:process.env.PAYSTACK_FREE_PLAN_CODE||null},
  {name:'Pro',price:15000,billingCycle:'month',features:['Unlimited products','Customers','Orders','Analytics'],providerPlanCode:process.env.PAYSTACK_PRO_PLAN_CODE||null},
  {name:'Business',price:50000,billingCycle:'month',features:['Everything in Pro','Advanced analytics','Priority support'],providerPlanCode:process.env.PAYSTACK_BUSINESS_PLAN_CODE||null}
 ],skipDuplicates:true});
 console.log('Softmall seed complete');
}
main().finally(()=>db.$disconnect());
