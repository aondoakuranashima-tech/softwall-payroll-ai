# Softmall

Multi-tenant SaaS starter for Web + Android + iOS.

## Stack
- Web: Next.js + TypeScript
- API: NestJS + TypeScript
- Mobile: Expo React Native
- Database: PostgreSQL + Prisma
- Monorepo: pnpm workspaces

## Quick start
1. Copy `.env.example` to `.env`.
2. Start PostgreSQL: `docker compose up -d postgres`
3. Install: `pnpm install`
4. Generate Prisma client: `pnpm db:generate`
5. Run migrations: `pnpm db:migrate`
6. Start web/API/mobile with the workspace scripts.

This repository is a production-oriented foundation; payment providers, email, push notifications, and cloud storage are isolated behind service boundaries for later configuration.
