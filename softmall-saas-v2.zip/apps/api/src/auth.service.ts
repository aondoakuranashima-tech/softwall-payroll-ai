import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { PrismaClient } from '@prisma/client';
const db=new PrismaClient();
@Injectable()
export class AuthService {
 constructor(private jwt:JwtService){}
 async register(name:string,email:string,password:string){
   const existing=await db.user.findUnique({where:{email}});
   if(existing) throw new UnauthorizedException('Email already registered');
   const passwordHash=await bcrypt.hash(password,12);
   const user=await db.user.create({data:{name,email,passwordHash}});
   return this.sign(user.id,user.email,user.role);
 }
 async login(email:string,password:string){
   const user=await db.user.findUnique({where:{email}});
   if(!user || !(await bcrypt.compare(password,user.passwordHash))) throw new UnauthorizedException('Invalid credentials');
   return this.sign(user.id,user.email,user.role);
 }
 private sign(id:string,email:string,role:string){return {accessToken:this.jwt.sign({sub:id,email,role})};}
}
