import { Module,MiddlewareConsumer,NestModule   configure(consumer:MiddlewareConsumer){consumer.apply(SecurityMiddleware).forRoutes('*');}
} from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthController } from './auth.controller'; import { AuthService } from './auth.service';
import { SaaSController } from './saas.controller'; import { SaaSService } from './saas.service';
import { OrgController } from './org.controller'; import { BillingController } from './billing.controller';
import { AdminController } from './admin.controller'; import { SecurityMiddleware } from './security.middleware';
import { SecurityController } from './security.controller';
import { SecurityService } from './security.service';
import { AccountController } from './account.controller';
import { InvitesController } from './invites.controller';
import { AuditController } from './audit.controller';
import { MembersController } from './members.controller';
import { PaymentController } from './payment.controller'; import { PaymentService } from './payment.service';
@Module({imports:[JwtModule.register({secret:process.env.JWT_SECRET||'dev-secret',signOptions:{expiresIn:'7d'}})],controllers:[SecurityController,AccountController,InvitesController,AuditController,MembersController,AuthController,SaaSController,OrgController,BillingController,AdminController,PaymentController],providers:[SecurityService,AuthService,SaaSService,PaymentService]})
export class AppModule implements NestModule {}