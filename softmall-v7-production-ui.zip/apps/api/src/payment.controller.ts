import { Controller, Get, Headers, Param, Post, Req, UseGuards, Body } from '@nestjs/common';
import { AuthGuard } from './auth.guard';
import { PaymentService } from './payment.service';
import { Roles } from './roles.decorator';
import { RolesGuard } from './roles.guard';
@Controller('payments')
export class PaymentController{
 constructor(private p:PaymentService){}
 @UseGuards(AuthGuard,RolesGuard)
 @Roles('ADMIN','OWNER')
 @Post('paystack/checkout') paystack(@Req() req:any,@Body('planId') planId:string){return this.p.paystackCheckout(req.user.sub,req.user.organizationId,planId);}
 @UseGuards(AuthGuard,RolesGuard)
 @Roles('ADMIN','OWNER')
 @Post('stripe/checkout') stripe(@Req() req:any,@Body('planId') planId:string){return this.p.stripeCheckout(req.user.sub,req.user.organizationId,planId);}
 @UseGuards(AuthGuard)
 @Get('paystack/verify/:reference') verify(@Param('reference') reference:string){return this.p.verifyPaystack(reference);}
 @Post('paystack/webhook') async paystackWebhook(@Req() req:any,@Headers('x-paystack-signature') sig:string){
  if(!this.p.paystackSignature(req.rawBody,sig)) return {received:false};
  const event=req.body; if(event.event==='charge.success') await this.p.fulfillPaystack(event.data); return {received:true};
 }
 @Post('stripe/webhook') stripeWebhook(@Req() req:any,@Headers('stripe-signature') sig:string){return this.p.handleStripeWebhook(req.rawBody,sig);}
}