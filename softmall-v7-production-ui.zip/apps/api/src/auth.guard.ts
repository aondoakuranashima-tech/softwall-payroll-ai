import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { db } from './prisma';
@Injectable()
export class AuthGuard implements CanActivate{
 constructor(private jwt:JwtService){}
 async canActivate(ctx:ExecutionContext){
  const req=ctx.switchToHttp().getRequest();
  const token=req.headers.authorization?.replace(/^Bearer\s+/,'');
  if(!token)throw new UnauthorizedException('Bearer token required');
  try{
   const p:any=this.jwt.verify(token);
   const m=await db.membership.findFirst({where:{userId:p.sub,organizationId:p.organizationId},select:{role:true,status:true}});
   if(!m||m.status!=='ACTIVE')throw new UnauthorizedException('Workspace access revoked');
   req.user={...p,role:m.role};
   return true;
  }catch(e){if(e instanceof UnauthorizedException)throw e;throw new UnauthorizedException('Invalid or expired token')}
 }
}
