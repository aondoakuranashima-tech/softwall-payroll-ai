# Softwall Payroll AI
Enterprise payroll SaaS foundation: Next.js web, NestJS API, Expo mobile, Prisma/PostgreSQL, RBAC, AI assistant, Stripe/Paystack adapters, and Docker.
