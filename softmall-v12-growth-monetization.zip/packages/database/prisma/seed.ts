import { PrismaClient } from '@prisma/client';
const db=new PrismaClient();
async function main(){
 await db.plan.createMany({data:[
  {name:'Free',price:0,billingCycle:'month',features:['Dashboard','10 products','Basic analytics']},
  {name:'Pro',price:15000,billingCycle:'month',features:['Unlimited products','Customers','Orders','Analytics']},
  {name:'Business',price:50000,billingCycle:'month',features:['Everything in Pro','Advanced analytics','Priority support']}
 ],skipDuplicates:true});
 console.log('Softmall seed complete');
}
main().finally(()=>db.$disconnect());
