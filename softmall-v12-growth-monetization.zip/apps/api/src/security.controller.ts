import {Body,Controller,Post,Query,UseGuards} from '@nestjs/common';import {SecurityService} from './security.service';import {RateLimitGuard} from './rate-limit.guard';
@Controller('security') export class SecurityController{
 constructor(private readonly security:SecurityService){}
 @UseGuards(new RateLimitGuard(10,60000)) @Post('verify-email') verify(@Query('token') token:string){return this.security.verify(token)}
 @UseGuards(new RateLimitGuard(5,60000)) @Post('request-reset') async request(@Body('email') email:string){const token=await this.security.issueReset(email);return {ok:true}}
 @UseGuards(new RateLimitGuard(10,60000)) @Post('reset-password') reset(@Body('token') token:string,@Body('password') password:string){if(!password||password.length<8)throw new Error('Password must be at least 8 characters');return this.security.reset(token,password)}
}