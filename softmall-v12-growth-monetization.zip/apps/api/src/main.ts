import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
async function bootstrap(){
 const app=await NestFactory.create(AppModule,{rawBody:true});
 app.enableCors({origin:true});
 app.enableCors({origin:(process.env.CORS_ORIGINS||process.env.APP_URL||'').split(',').map(x=>x.trim()).filter(Boolean),credentials:true});
  app.useGlobalPipes(new ValidationPipe({whitelist:true,transform:true}));
 await app.listen(process.env.PORT ?? 4000);
}
bootstrap();
