import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { createHmac } from 'crypto';
import Stripe from 'stripe';
import { db } from './prisma';

@Injectable()
export class PaymentService {
 private stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;
 private paystackKey = process.env.PAYSTACK_SECRET_KEY;
 private appUrl = process.env.APP_URL || 'http://localhost:3000';

 async paystackCheckout(userId:string, organizationId:string, planId:string){
  if(!this.paystackKey) throw new BadRequestException('PAYSTACK_SECRET_KEY is not configured');
  const plan=await db.plan.findUnique({where:{id:planId}}); if(!plan) throw new NotFoundException('Plan not found');
  const user=await db.user.findUnique({where:{id:userId}}); if(!user) throw new NotFoundException('User not found');
  const reference=`SM-PS-${organizationId}-${Date.now()}`;
  const res=await fetch('https://api.paystack.co/transaction/initialize',{method:'POST',headers:{Authorization:`Bearer ${this.paystackKey}`,'Content-Type':'application/json'},body:JSON.stringify({
   email:user.email,amount:String(plan.price),currency:plan.currency,reference,callback_url:`${this.appUrl}/billing?provider=paystack&reference=${reference}`,metadata:{organizationId,userId,planId}
  })});
  const data:any=await res.json(); if(!res.ok||!data.status) throw new BadRequestException(data.message||'Paystack initialization failed');
  await db.transaction.create({data:{organizationId,userId,amount:plan.price,currency:plan.currency,provider:'paystack',reference,metadata:data.data}});
  return {provider:'paystack',authorizationUrl:data.data.authorization_url,accessCode:data.data.access_code,reference};
 }

 async verifyPaystack(reference:string){
  if(!this.paystackKey) throw new BadRequestException('PAYSTACK_SECRET_KEY is not configured');
  const tx=await db.transaction.findUnique({where:{reference}}); if(!tx) throw new NotFoundException('Transaction not found');
  const res=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{headers:{Authorization:`Bearer ${this.paystackKey}`}});
  const data:any=await res.json(); if(!res.ok||!data.status) throw new BadRequestException(data.message||'Verification failed');
  await this.fulfillPaystack(data.data);
  return data.data;
 }

 async stripeCheckout(userId:string, organizationId:string, planId:string){
  if(!this.stripe) throw new BadRequestException('STRIPE_SECRET_KEY is not configured');
  const plan=await db.plan.findUnique({where:{id:planId}}); if(!plan) throw new NotFoundException('Plan not found');
  const user=await db.user.findUnique({where:{id:userId}}); if(!user) throw new NotFoundException('User not found');
  const session=await this.stripe.checkout.sessions.create({
   mode:'payment',customer_email:user.email,
   line_items:[{price_data:{currency:plan.currency.toLowerCase(),product_data:{name:`Softmall ${plan.name} plan`},unit_amount:plan.price},quantity:1}],
   metadata:{organizationId,userId,planId},success_url:`${this.appUrl}/billing?provider=stripe&session_id={CHECKOUT_SESSION_ID}`,cancel_url:`${this.appUrl}/billing?canceled=1`
  });
  const reference=`SM-ST-${session.id}`;
  await db.transaction.create({data:{organizationId,userId,amount:plan.price,currency:plan.currency,provider:'stripe',providerTransactionId:session.id,reference,metadata:{sessionId:session.id}}});
  return {provider:'stripe',checkoutUrl:session.url,sessionId:session.id,reference};
 }

 async fulfillPaystack(data:any){
  if(data.status!=='success') return;
  const tx=await db.transaction.findUnique({where:{reference:data.reference}});
  if(!tx || tx.status==='SUCCEEDED') return;
  if(Number(data.amount)!==tx.amount) throw new BadRequestException('Payment amount mismatch');
  const meta=(tx.metadata||{}) as any; const planId=meta.planId || data.metadata?.planId;
  await db.$transaction([
   db.transaction.update({where:{id:tx.id},data:{status:'SUCCEEDED',providerTransactionId:String(data.id),metadata:data}}),
   db.subscription.upsert({where:{organizationId:tx.organizationId},update:{planId,status:'ACTIVE',startDate:new Date(),renewalDate:new Date(Date.now()+30*86400000),provider:'paystack',providerSubscriptionId:String(data.id)},create:{organizationId:tx.organizationId,planId:planId,status:'ACTIVE',provider:'paystack',providerSubscriptionId:String(data.id),renewalDate:new Date(Date.now()+30*86400000)}})
  ]);
 }

 async handleStripeWebhook(raw:Buffer,signature:string){
  if(!this.stripe || !process.env.STRIPE_WEBHOOK_SECRET) throw new BadRequestException('Stripe webhook is not configured');
  const event=this.stripe.webhooks.constructEvent(raw,signature,process.env.STRIPE_WEBHOOK_SECRET);
  if(event.type==='checkout.session.completed'){
   const session=event.data.object as Stripe.Checkout.Session;
   if(session.payment_status!=='paid') return {received:true};
   const tx=await db.transaction.findFirst({where:{provider:'stripe',providerTransactionId:session.id}});
   if(tx && tx.status!=='SUCCEEDED'){
    const planId=session.metadata?.planId;
    if(planId) await db.$transaction([
     db.transaction.update({where:{id:tx.id},data:{status:'SUCCEEDED',metadata:session as any}}),
     db.subscription.upsert({where:{organizationId:tx.organizationId},update:{planId,status:'ACTIVE',startDate:new Date(),renewalDate:new Date(Date.now()+30*86400000),provider:'stripe',providerSubscriptionId:session.id},create:{organizationId:tx.organizationId,planId,status:'ACTIVE',provider:'stripe',providerSubscriptionId:session.id,renewalDate:new Date(Date.now()+30*86400000)}})
    ]);
   }
  }
  return {received:true};
 }

 paystackSignature(raw:Buffer,signature:string){return createHmac('sha512',this.paystackKey||'').update(raw).digest('hex')===signature;}
}