import {BadRequestException,Body,Controller,Get,Param,Post,Req,UseGuards} from '@nestjs/common';
import {randomBytes} from 'crypto'; import {db} from './prisma'; import {AuthGuard} from './auth.guard'; import {Roles} from './roles.decorator'; import {RolesGuard} from './roles.guard';
@Controller('invites') @UseGuards(AuthGuard,RolesGuard) @Roles('OWNER','ADMIN')
export class InvitesController{
 @Get() list(@Req() req:any){return db.membership.findMany({where:{organizationId:req.user.organizationId,status:'INVITED'},include:{user:{select:{id:true,name:true,email:true}}}});}
 @Post() async create(@Req() req:any,@Body('email') email:string,@Body('role') role='STAFF'){
  if(!email)throw new BadRequestException('Email is required');
  if(!['ADMIN','MANAGER','STAFF'].includes(role))throw new BadRequestException('Invalid invite role');
  const user=await db.user.findUnique({where:{email}});
  if(!user)throw new BadRequestException('User must create a Softmall account before being invited');
  const exists=await db.membership.findFirst({where:{organizationId:req.user.organizationId,userId:user.id}});
  if(exists)throw new BadRequestException('User is already associated with this workspace');
  const inviteToken=randomBytes(24).toString('hex');
  const membership=await db.membership.create({data:{organizationId:req.user.organizationId,userId:user.id,role,status:'INVITED'}});
  return {id:membership.id,email,role,inviteToken};
 }
 @Post(':id/accept') async accept(@Req() req:any,@Param('id') id:string){
  const m=await db.membership.findUnique({where:{id}});
  if(!m||m.userId!==req.user.sub)throw new BadRequestException('Invite not found');
  return db.membership.update({where:{id},data:{status:'ACTIVE'}});
 }
}