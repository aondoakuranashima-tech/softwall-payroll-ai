import { Body, Controller, Post } from '@nestjs/common';
import { IsEmail, IsString, MinLength } from 'class-validator';
import { AuthService } from './auth.service';
export class RegisterDto { @IsString() name!:string; @IsEmail() email!:string; @MinLength(8) password!:string; }
export class LoginDto { @IsEmail() email!:string; @IsString() password!:string; }
@Controller('auth')
export class AuthController {
 constructor(private auth:AuthService){}
 @Post('register') register(@Body() d:RegisterDto){return this.auth.register(d.name,d.email,d.password);}
 @Post('login') login(@Body() d:LoginDto){return this.auth.login(d.email,d.password);}
}