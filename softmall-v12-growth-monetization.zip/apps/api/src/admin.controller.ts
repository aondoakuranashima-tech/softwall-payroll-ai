import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { AuthGuard } from './auth.guard';
import { db } from './prisma';
@Controller('admin')
@UseGuards(AuthGuard)
export class AdminController{
 @Get('overview') async overview(){
  const [users,orgs,products,orders,tx]=await Promise.all([
   db.user.count(),db.organization.count(),db.product.count(),db.order.count(),db.transaction.aggregate({_sum:{amount:true}})
  ]);
  return {users,organizations:orgs,products,orders,transactionVolume:tx._sum.amount??0};
 }
 @Get('users') users(@Query('take') take='50'){return db.user.findMany({take:Math.min(Number(take)||50,100),select:{id:true,name:true,email:true,role:true,status:true,createdAt:true},orderBy:{createdAt:'desc'}});}
}