import { Body, Controller, Headers, Post, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from './auth.guard';
import { PaymentsService } from './payments.service';

@Controller('payments')
export class PaymentsController{
 constructor(private payments:PaymentsService){}
 @UseGuards(AuthGuard)
 @Post('paystack/checkout') paystack(@Req() req:any,@Body('planId') planId:string){return this.payments.initializePaystack(req.user.sub,req.user.organizationId,planId);}
 @UseGuards(AuthGuard)
 @Post('stripe/checkout') stripe(@Req() req:any,@Body('planId') planId:string){return this.payments.initializeStripe(req.user.sub,req.user.organizationId,planId);}
 @Post('paystack/webhook') paystackWebhook(@Req() req:any,@Headers('x-paystack-signature') sig:string){return this.payments.handlePaystackWebhook(req.rawBody,sig);}
 @Post('stripe/webhook') stripeWebhook(@Req() req:any,@Headers('stripe-signature') sig:string){return this.payments.handleStripeWebhook(req.rawBody,sig);}
 @UseGuards(AuthGuard)
 @Post('paystack/verify') verify(@Body('reference') reference:string){return this.payments.verifyPaystack(reference);}
}