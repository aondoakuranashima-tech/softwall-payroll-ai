import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { db } from './prisma';

@Injectable()
export class SaaSService {
  products(organizationId:string){ return db.product.findMany({where:{organizationId},orderBy:{createdAt:'desc'}}); }
  createProduct(d:any){ return db.product.create({data:d}); }
  updateProduct(id:string,d:any){ delete d.organizationId; return db.product.update({where:{id},data:d}); }
  deleteProduct(id:string){ return db.product.update({where:{id},data:{active:false}}); }

  customers(organizationId:string){ return db.customer.findMany({where:{organizationId},orderBy:{createdAt:'desc'}}); }
  createCustomer(d:any){ return db.customer.create({data:d}); }

  orders(organizationId:string){
    return db.order.findMany({where:{organizationId},include:{customer:true,items:{include:{product:true}}},orderBy:{createdAt:'desc'}});
  }

  async createOrder(d:{organizationId:string;customerId?:string;items:{productId:string;quantity:number}[]}){
    if(!d.items?.length) throw new BadRequestException('Order must contain items');
    const products=await db.product.findMany({where:{id:{in:d.items.map(i=>i.productId)},organizationId:d.organizationId,active:true}});
    if(products.length!==d.items.length) throw new BadRequestException('One or more products are invalid');
    const lines=d.items.map(i=>{
      const p=products.find(x=>x.id===i.productId)!;
      if(i.quantity<1 || p.stock<i.quantity) throw new BadRequestException(`Insufficient stock for ${p.name}`);
      return {productId:p.id,quantity:i.quantity,unitPrice:p.price,lineTotal:p.price*i.quantity};
    });
    const subtotal=lines.reduce((n,x)=>n+x.lineTotal,0);
    return db.$transaction(async tx=>{
      const order=await tx.order.create({data:{organizationId:d.organizationId,customerId:d.customerId,subtotal,total:subtotal,items:{create:lines}}});
      for(const line of lines) await tx.product.update({where:{id:line.productId},data:{stock:{decrement:line.quantity}}});
      return order;
    });
  }
  updateOrderStatus(id:string,status:string){
    const allowed=['PENDING','PROCESSING','SHIPPED','DELIVERED','CANCELED'];
    if(!allowed.includes(status)) throw new BadRequestException('Invalid order status');
    return db.order.update({where:{id},data:{status:status as any}});
  }
  async analytics(organizationId:string){
    const [orders,products,customers,paid]=await Promise.all([
      db.order.count({where:{organizationId}}),
      db.product.count({where:{organizationId,active:true}}),
      db.customer.count({where:{organizationId}}),
      db.order.aggregate({where:{organizationId,status:{not:'CANCELED'}},_sum:{total:true}})
    ]);
    return {orders,products,customers,revenue:paid._sum.total??0};
  }
}
