import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { createHmac, timingSafeEqual } from 'crypto';
import { db } from './prisma';

@Injectable()
export class PaymentsService {
 private async paystack(path:string,body?:any){
  const key=process.env.PAYSTACK_SECRET_KEY;
  if(!key) throw new BadRequestException('PAYSTACK_SECRET_KEY is not configured');
  const r=await fetch(`https://api.paystack.co${path}`,{method:body?'POST':'GET',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});
  const d=await r.json();
  if(!r.ok || !d.status) throw new BadRequestException(d.message||'Paystack request failed');
  return d.data;
 }
 async initializePaystack(userId:string,organizationId:string,planId:string){
  const plan=await db.plan.findUnique({where:{id:planId}}); if(!plan) throw new NotFoundException('Plan not found');
  if(plan.price<=0) return db.subscription.upsert({where:{organizationId},update:{planId,status:'ACTIVE'},create:{organizationId,planId,status:'ACTIVE'}});
  const user=await db.user.findUnique({where:{id:userId}}); if(!user) throw new NotFoundException('User not found');
  const reference=`SM-${organizationId}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
  const tx=await db.transaction.create({data:{organizationId,userId,amount:plan.price,currency:plan.currency,provider:'paystack',reference,status:'PENDING'}});
  const data=await this.paystack('/transaction/initialize',{email:user.email,amount:String(plan.price),currency:plan.currency,reference,callback_url:process.env.PAYSTACK_CALLBACK_URL,metadata:{softmallTransactionId:tx.id,organizationId,planId}});
  return {reference,authorizationUrl:data.authorization_url,accessCode:data.access_code,transactionId:tx.id};
 }
 async verifyPaystack(reference:string){
  const data=await this.paystack(`/transaction/verify/${encodeURIComponent(reference)}`);
  if(data.status==='success') await this.fulfill(reference,'paystack',data);
  return data;
 }
 verifySignature(raw:Buffer,signature:string,secret:string){
  const expected=createHmac('sha512',secret).update(raw).digest('hex');
  if(!signature) return false;
  const a=Buffer.from(expected,'utf8'),b=Buffer.from(signature,'utf8');
  return a.length===b.length && timingSafeEqual(a,b);
 }
 async handlePaystackWebhook(raw:Buffer,signature:string){
  const secret=process.env.PAYSTACK_SECRET_KEY;if(!secret) throw new BadRequestException('Paystack secret not configured');
  if(!this.verifySignature(raw,signature,secret)) throw new BadRequestException('Invalid Paystack signature');
  const event=JSON.parse(raw.toString('utf8'));
  if(event.event==='charge.success') await this.fulfill(event.data.reference,'paystack',event.data);
  return {received:true};
 }
 private async fulfill(reference:string,provider:string,data:any){
  const tx=await db.transaction.findUnique({where:{reference}});
  if(!tx) return;
  if(tx.status==='SUCCEEDED') return;
  if(provider==='paystack' && data.status!=='success') return;
  if(Number(data.amount)!==tx.amount || String(data.currency).toUpperCase()!==tx.currency.toUpperCase()) throw new BadRequestException('Payment amount/currency mismatch');
  await db.$transaction(async t=>{
   await t.transaction.update({where:{id:tx.id},data:{status:'SUCCEEDED'}});
   const meta=data.metadata||{};
   if(meta.planId){
    await t.subscription.upsert({where:{organizationId:tx.organizationId},update:{planId:meta.planId,status:'ACTIVE',startDate:new Date()},create:{organizationId:tx.organizationId,planId:meta.planId,status:'ACTIVE'}});
   }
  });
 }
 async initializeStripe(userId:string,organizationId:string,planId:string){
  const secret=process.env.STRIPE_SECRET_KEY;if(!secret) throw new BadRequestException('STRIPE_SECRET_KEY is not configured');
  const plan=await db.plan.findUnique({where:{id:planId}});if(!plan)throw new NotFoundException('Plan not found');
  if(plan.price<=0)return db.subscription.upsert({where:{organizationId},update:{planId,status:'ACTIVE'},create:{organizationId,planId,status:'ACTIVE'}});
  const user=await db.user.findUnique({where:{id:userId}});if(!user)throw new NotFoundException('User not found');
  const reference=`STR-${organizationId}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
  const tx=await db.transaction.create({data:{organizationId,userId,amount:plan.price,currency:plan.currency,provider:'stripe',reference,status:'PENDING'}});
  const params=new URLSearchParams();
  params.set('mode','payment');params.set('success_url',`${process.env.STRIPE_SUCCESS_URL||'http://localhost:3000/billing/success'}?session_id={CHECKOUT_SESSION_ID}`);
  params.set('cancel_url',process.env.STRIPE_CANCEL_URL||'http://localhost:3000/billing');
  params.set('customer_email',user.email);
  params.set('line_items[0][quantity]','1');
  params.set('line_items[0][price_data][currency]',plan.currency.toLowerCase());
  params.set('line_items[0][price_data][unit_amount]',String(plan.price));
  params.set('line_items[0][price_data][product_data][name]',`Softmall ${plan.name} plan`);
  params.set('metadata[softmallTransactionId]',tx.id);params.set('metadata[organizationId]',organizationId);params.set('metadata[planId]',planId);params.set('metadata[reference]',reference);
  const r=await fetch('https://api.stripe.com/v1/checkout/sessions',{method:'POST',headers:{Authorization:`Bearer ${secret}`,'Content-Type':'application/x-www-form-urlencoded'},body:params});
  const data=await r.json();if(!r.ok)throw new BadRequestException(data.error?.message||'Stripe request failed');
  return {reference,transactionId:tx.id,checkoutUrl:data.url,sessionId:data.id};
 }
 async handleStripeWebhook(raw:Buffer,signature:string){
  const secret=process.env.STRIPE_WEBHOOK_SECRET;if(!secret)throw new BadRequestException('STRIPE_WEBHOOK_SECRET is not configured');
  const event=this.verifyStripe(raw,signature,secret);
  if(event.type==='checkout.session.completed'){
   const s=event.data.object; if(s.payment_status==='paid'){
    const meta=s.metadata||{}; const tx=await db.transaction.findUnique({where:{id:meta.softmallTransactionId}});
    if(tx && tx.status!=='SUCCEEDED'){
     const amount=Number(s.amount_total); const currency=String(s.currency||'').toUpperCase();
     if(amount!==tx.amount||currency!==tx.currency.toUpperCase())throw new BadRequestException('Stripe amount/currency mismatch');
     await db.$transaction(async t=>{
      await t.transaction.update({where:{id:tx.id},data:{status:'SUCCEEDED'}});
      if(meta.planId)await t.subscription.upsert({where:{organizationId:tx.organizationId},update:{planId:meta.planId,status:'ACTIVE',startDate:new Date()},create:{organizationId:tx.organizationId,planId:meta.planId,status:'ACTIVE'}});
     });
    }
   }
  }
  return {received:true};
 }
 private verifyStripe(raw:Buffer,header:string,secret:string){
  const parts=Object.fromEntries(header.split(',').map(x=>x.split('=')));
  const ts=parts.t,v1=parts.v1;if(!ts||!v1)throw new BadRequestException('Invalid Stripe signature');
  const age=Math.abs(Date.now()/1000-Number(ts));if(age>300)throw new BadRequestException('Expired Stripe signature');
  const expected=createHmac('sha256',secret).update(`${ts}.${raw.toString('utf8')}`).digest('hex');
  const a=Buffer.from(expected),b=Buffer.from(v1);if(a.length!==b.length||!timingSafeEqual(a,b))throw new BadRequestException('Invalid Stripe signature');
  return JSON.parse(raw.toString('utf8'));
 }
}