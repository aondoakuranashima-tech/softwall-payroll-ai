import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { db } from './prisma';
@Injectable()
export class BillingService{
 plans(){return db.plan.findMany({orderBy:{price:'asc'}});}
 subscription(organizationId:string){return db.subscription.findUnique({where:{organizationId},include:{plan:true}});}
 transactions(organizationId:string){return db.transaction.findMany({where:{organizationId},orderBy:{createdAt:'desc'}});}
 async subscribe(organizationId:string,userId:string,planId:string){
  const plan=await db.plan.findUnique({where:{id:planId}});if(!plan)throw new NotFoundException('Plan not found');
  if(plan.price===0)return db.subscription.upsert({where:{organizationId},update:{planId,status:'ACTIVE',renewalDate:null},create:{organizationId,planId,status:'ACTIVE'}});
  // Provider-neutral billing intent. Connect Paystack/Stripe keys in production.
  const reference=`SUB-${organizationId}-${Date.now()}`;
  await db.transaction.create({data:{organizationId,userId,amount:plan.price,currency:plan.currency,provider:'pending',reference,status:'PENDING'}});
  throw new BadRequestException({message:'Payment required before activation',reference,amount:plan.price,currency:plan.currency});
 }
}