import {Body,Controller,Get,Post,Req,UseGuards} from '@nestjs/common';import {randomBytes,createHash} from 'crypto';import {AuthGuard} from './auth.guard';import {Roles} from './roles.decorator';import {RolesGuard} from './roles.guard';import {db} from './prisma';
@Controller('developer') @UseGuards(AuthGuard,RolesGuard) @Roles('OWNER','ADMIN')
export class DeveloperController{
 @Get('keys') async keys(@Req() req:any){const x:any=db;return x.apiKey?x.apiKey.findMany({where:{organizationId:req.user.organizationId},select:{id:true,name:true,lastUsedAt:true,createdAt:true}}):[]}
 @Post('keys') async create(@Req() req:any,@Body('name') name='Production key'){const raw='sm_'+randomBytes(24).toString('hex');const hash=createHash('sha256').update(raw).digest('hex');const x:any=db;if(!x.apiKey)return {key:raw,warning:'Add an ApiKey Prisma model before persistence'};const k=await x.apiKey.create({data:{organizationId:req.user.organizationId,name,keyHash:hash}});return {id:k.id,key:raw}}
}