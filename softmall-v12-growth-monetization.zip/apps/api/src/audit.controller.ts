import {Controller,Get,Req,UseGuards} from '@nestjs/common'; import {db} from './prisma'; import {AuthGuard} from './auth.guard'; import {Roles} from './roles.decorator'; import {RolesGuard} from './roles.guard';
@Controller('audit') @UseGuards(AuthGuard,RolesGuard) @Roles('OWNER','ADMIN')
export class AuditController{
 @Get() async list(@Req() req:any){
  const anyDb:any=db;
  if(!anyDb.auditLog)return [];
  return anyDb.auditLog.findMany({where:{organizationId:req.user.organizationId},orderBy:{createdAt:'desc'},take:100});
 }
}