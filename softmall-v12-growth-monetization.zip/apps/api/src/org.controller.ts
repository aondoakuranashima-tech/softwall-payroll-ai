import { Body, Controller, Get, Param, Patch, UseGuards, Req } from '@nestjs/common';
import { IsOptional, IsString } from 'class-validator';
import { AuthGuard } from './auth.guard';
import { db } from './prisma';
import { Roles } from './roles.decorator';
import { RolesGuard } from './roles.guard';
class OrgDto{@IsString() name!:string;@IsOptional() @IsString() logo?:string}
@Controller('organizations')
@UseGuards(AuthGuard)
export class OrgController{
 @Get('me') me(@Req() req:any){return db.organization.findUnique({where:{id:req.user.organizationId},include:{subscription:{include:{plan:true}},memberships:{include:{user:true}}}});}
 @Roles('ADMIN','OWNER')
 @UseGuards(RolesGuard)
 @Patch('me') update(@Req() req:any,@Body() dto:OrgDto){return db.organization.update({where:{id:req.user.organizationId},data:dto});}
 @Roles('ADMIN','OWNER')
 @UseGuards(RolesGuard)
 @Get(':id/members') members(@Param('id') id:string){return db.membership.findMany({where:{organizationId:id},include:{user:true}});}
}