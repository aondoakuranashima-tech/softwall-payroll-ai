import {Body,Controller,Get,Patch,Req,UseGuards} from '@nestjs/common';
import {db} from './prisma'; import {AuthGuard} from './auth.guard'; import {Roles} from './roles.decorator'; import {RolesGuard} from './roles.guard';
@Controller('account') @UseGuards(AuthGuard)
export class AccountController{
 @Get('me') async me(@Req() req:any){return db.user.findUnique({where:{id:req.user.sub},select:{id:true,name:true,email:true,status:true,createdAt:true}});}
 @Get('organization') async organization(@Req() req:any){return db.organization.findUnique({where:{id:req.user.organizationId},include:{_count:{select:{memberships:true,products:true,customers:true,orders:true}}}});}
 @Patch('organization') @UseGuards(RolesGuard) @Roles('OWNER','ADMIN')
 async update(@Req() req:any,@Body() b:any){return db.organization.update({where:{id:req.user.organizationId},data:{name:b.name,slug:b.slug}});}
}