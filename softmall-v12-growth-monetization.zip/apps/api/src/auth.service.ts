import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { db } from './prisma';
@Injectable()
export class AuthService {
 constructor(private jwt:JwtService){}
 async register(name:string,email:string,password:string){
  if(await db.user.findUnique({where:{email}})) throw new UnauthorizedException('Email already registered');
  const user=await db.user.create({data:{name,email,passwordHash:await bcrypt.hash(password,12)}});
  return this.sign(user);
 }
 async login(email:string,password:string){
  const user=await db.user.findUnique({where:{email}});
  if(!user || !(await bcrypt.compare(password,user.passwordHash))) throw new UnauthorizedException('Invalid credentials');
  return this.sign(user);
 }
 private async sign(user:any){
  let membership=await db.membership.findFirst({where:{userId:user.id},include:{organization:true}});
  if(!membership){
   const org=await db.organization.create({data:{name:`${user.name}'s business`,slug:`${user.id}-${Date.now()}`,ownerId:user.id}});
   membership=await db.membership.create({data:{userId:user.id,organizationId:org.id,role:'ADMIN'},include:{organization:true}});
  }
  return {accessToken:this.jwt.sign({sub:user.id,email:user.email,role:membership.role,organizationId:membership.organizationId}),user:{id:user.id,name:user.name,email:user.email},organization:membership.organization};
 }
}