import {Injectable,UnauthorizedException} from '@nestjs/common';
import {randomBytes,createHash} from 'crypto'; import * as bcrypt from 'bcryptjs'; import {db} from './prisma';
@Injectable()
export class SecurityService{
 token(raw:string){return createHash('sha256').update(raw).digest('hex')}
 async issueVerification(userId:string){const raw=randomBytes(32).toString('hex');await db.verificationToken.deleteMany({where:{userId}});await db.verificationToken.create({data:{userId,token:this.token(raw),expiresAt:new Date(Date.now()+24*3600e3)}});return raw}
 async verify(raw:string){const x=await db.verificationToken.findUnique({where:{token:this.token(raw)}});if(!x||x.expiresAt<new Date())throw new UnauthorizedException('Verification link is invalid or expired');await db.user.update({where:{id:x.userId},data:{emailVerified:true}});await db.verificationToken.delete({where:{id:x.id}});return true}
 async issueReset(email:string){const u=await db.user.findUnique({where:{email}});if(!u)return null;const raw=randomBytes(32).toString('hex');await db.passwordResetToken.deleteMany({where:{userId:u.id}});await db.passwordResetToken.create({data:{userId:u.id,token:this.token(raw),expiresAt:new Date(Date.now()+60*60e3)}});return raw}
 async reset(raw:string,password:string){const x=await db.passwordResetToken.findUnique({where:{token:this.token(raw)}});if(!x||x.expiresAt<new Date())throw new UnauthorizedException('Reset link is invalid or expired');const hash=await bcrypt.hash(password,12);await db.user.update({where:{id:x.userId},data:{passwordHash:hash}});await db.passwordResetToken.delete({where:{id:x.id}});return true}
}