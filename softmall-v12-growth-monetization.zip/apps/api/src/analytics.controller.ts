import {Controller,Get,Req,Query,UseGuards} from '@nestjs/common';
import {db} from './prisma'; import {AuthGuard} from './auth.guard';
@Controller('analytics') @UseGuards(AuthGuard)
export class AnalyticsController{
 @Get('overview') async overview(@Req() req:any,@Query('from') from?:string,@Query('to') to?:string){
  const start=from?new Date(from):new Date(Date.now()-30*864e5), end=to?new Date(to):new Date();
  const where:any={organizationId:req.user.organizationId,createdAt:{gte:start,lte:end}};
  const [orders,customers,products]=await Promise.all([
   db.order.findMany({where,select:{id:true,total:true,status:true,createdAt:true}}),
   db.customer.count({where:{organizationId:req.user.organizationId,createdAt:{gte:start,lte:end}}}),
   db.product.findMany({where:{organizationId:req.user.organizationId},select:{id:true,name:true,price:true,stock:true}})
  ]);
  const revenue=orders.filter((o:any)=>!['CANCELLED','REFUNDED'].includes(o.status)).reduce((n:any,o:any)=>n+Number(o.total||0),0);
  return {from:start,to:end,revenue,orders:orders.length,customers,products:products.length,lowStock:products.filter((p:any)=>p.stock<=5).length,topProducts:products.sort((a:any,b:any)=>b.price-a.price).slice(0,5)};
 }
}