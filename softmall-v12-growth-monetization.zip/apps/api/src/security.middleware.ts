import {Injectable,NestMiddleware} from '@nestjs/common';import {Request,Response,NextFunction} from 'express';import helmet from 'helmet';import crypto from 'crypto';
@Injectable() export class SecurityMiddleware implements NestMiddleware{
 private h=helmet({contentSecurityPolicy:false,crossOriginEmbedderPolicy:false});
 use(req:Request,res:Response,next:NextFunction){this.h(req,res,()=>{const id=crypto.randomUUID();res.setHeader('X-Request-ID',id);res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');res.setHeader('Permissions-Policy','camera=(),microphone=(),geolocation=()');next()})}
}