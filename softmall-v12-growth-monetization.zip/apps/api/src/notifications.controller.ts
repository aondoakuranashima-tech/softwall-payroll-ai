import {Controller,Get,Patch,Req,UseGuards} from '@nestjs/common';import {AuthGuard} from './auth.guard';import {db} from './prisma';
@Controller('notifications') @UseGuards(AuthGuard)
export class NotificationsController{
 @Get() list(@Req() req:any){const x:any=db;return x.notification?x.notification.findMany({where:{userId:req.user.sub},orderBy:{createdAt:'desc'},take:50}):[]}
 @Patch(':id/read') async read(@Req() req:any){return {ok:true}}
}