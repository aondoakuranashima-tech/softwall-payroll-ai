import { Body, Controller, Delete, Get, Param, Patch, Post, Req, UseGuards } from '@nestjs/common';
import { db } from './prisma';
import { AuthGuard } from './auth.guard';
import { Roles } from './roles.decorator';
import { RolesGuard } from './roles.guard';

@Controller('members')
@UseGuards(AuthGuard,RolesGuard)
@Roles('ADMIN','OWNER')
export class MembersController{
 @Get() list(@Req() req:any){return db.membership.findMany({where:{organizationId:req.user.organizationId},include:{user:{select:{id:true,name:true,email:true,status:true}}},orderBy:{createdAt:'asc'}});}
 @Patch(':id/role') async role(@Req() req:any,@Param('id') id:string,@Body('role') role:string){
  if(!['ADMIN','MANAGER','STAFF','OWNER'].includes(role))throw new Error('Invalid role');
  const target=await db.membership.findUnique({where:{id}});
  if(!target||target.organizationId!==req.user.organizationId)throw new Error('Member not found');
  if(target.role==='OWNER' && role!=='OWNER')throw new Error('Owner cannot be demoted');
  return db.membership.update({where:{id},data:{role}});
 }
 @Patch(':id/status') async status(@Req() req:any,@Param('id') id:string,@Body('status') status:string){
  const target=await db.membership.findUnique({where:{id}});
  if(!target||target.organizationId!==req.user.organizationId)throw new Error('Member not found');
  if(target.userId===req.user.sub)throw new Error('You cannot deactivate yourself');
  return db.membership.update({where:{id},data:{status}});
 }
}
