import {Body,Controller,Get,Post,Req,UseGuards} from '@nestjs/common'; import {AuthGuard} from './auth.guard'; import {Roles} from './roles.decorator'; import {RolesGuard} from './roles.guard';
@Controller('marketing') @UseGuards(AuthGuard,RolesGuard) @Roles('OWNER','ADMIN','MANAGER')
export class MarketingController { @Get('campaigns') campaigns(){return []} @Post('campaigns') create(@Req() req:any,@Body() b:any){return {id:'campaign_'+Date.now(),organizationId:req.user.organizationId,name:b.name,channel:b.channel||'EMAIL',status:'DRAFT',audience:b.audience||'ALL',createdAt:new Date()}} }
