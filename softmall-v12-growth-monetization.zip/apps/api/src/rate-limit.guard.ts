import {CanActivate,ExecutionContext,Injectable,TooManyRequestsException} from '@nestjs/common';
const buckets=new Map<string,{start:number,count:number}>();
@Injectable() export class RateLimitGuard implements CanActivate{
 constructor(private limit=60,private windowMs=60000){}
 canActivate(ctx:ExecutionContext){const r=ctx.switchToHttp().getRequest();const key=`${r.ip}:${r.path}`;const now=Date.now();let b=buckets.get(key);if(!b||now-b.start>=this.windowMs)b={start:now,count:0};b.count++;buckets.set(key,b);if(b.count>this.limit)throw new TooManyRequestsException('Too many requests');return true}
}