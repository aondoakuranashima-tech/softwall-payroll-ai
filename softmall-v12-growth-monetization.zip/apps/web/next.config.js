/** @type {import('next').NextConfig} */
const nextConfig={async headers(){return[{source:'/:path*',headers:[
{name:'X-Frame-Options',value:'DENY'},
{name:'X-Content-Type-Options',value:'nosniff'},
{name:'Referrer-Policy',value:'strict-origin-when-cross-origin'},
{name:'Permissions-Policy',value:'camera=(), microphone=(), geolocation=()'},
{name:'Strict-Transport-Security',value:'max-age=31536000; includeSubDomains; preload'}
]}]}}
module.exports=nextConfig;
