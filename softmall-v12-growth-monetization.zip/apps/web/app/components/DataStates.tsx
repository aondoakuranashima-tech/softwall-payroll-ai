export function Loading(){return <div className="state"><div className="spinner"/><span>Loading…</span></div>}
export function ErrorState({message,onRetry}:{message:string,onRetry?:()=>void}){return <div className="state errorstate"><b>Something went wrong</b><span>{message}</span>{onRetry&&<button onClick={onRetry}>Try again</button>}</div>}
export function Empty({title,text}:{title:string,text:string}){return <div className="state"><div className="emptyicon">○</div><b>{title}</b><span>{text}</span></div>}
