export const API=process.env.NEXT_PUBLIC_API_URL||'http://localhost:4000';
export function token(){return typeof window==='undefined'?'':localStorage.getItem('softmall_token')||''}
export function orgId(){try{return JSON.parse(atob(token().split('.')[1].replace(/-/g,'+').replace(/_/g,'/'))).organizationId}catch{return ''}}
export async function api(path:string,options:any={}){const headers={'content-type':'application/json',...(options.headers||{}),Authorization:`Bearer ${token()}`};const r=await fetch(`${API}${path}`,{...options,headers});const d=await r.json().catch(()=>null);if(!r.ok)throw new Error(d?.message||'Request failed');return d}
