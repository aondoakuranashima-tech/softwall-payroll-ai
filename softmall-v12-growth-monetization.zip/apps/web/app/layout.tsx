import './globals.css';
export const metadata={title:'Softmall — Business OS',description:'Products, customers, orders and billing in one SaaS workspace'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
