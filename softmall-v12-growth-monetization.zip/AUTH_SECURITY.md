# Authentication security

- Verification tokens are SHA-256 hashed at rest and expire after 24 hours.
- Password reset tokens are SHA-256 hashed at rest and expire after 1 hour.
- Passwords are hashed with bcrypt cost 12.
- Reset requests should always return a generic success response in production to prevent account enumeration.
- Replace the development reset-token response with a transactional email provider.
- Use HTTPS, secure cookies/session rotation, rate limits, CSRF protection where cookie auth is used, and MFA for administrators.
