# Softmall production checklist

1. Provision PostgreSQL.
2. Set DATABASE_URL and JWT_SECRET.
3. Run Prisma migrations and seed plans.
4. Set APP_URL and NEXT_PUBLIC_API_URL.
5. Configure Paystack and Stripe live credentials.
6. Register payment webhooks:
   - POST /payments/paystack/webhook
   - POST /payments/stripe/webhook
7. Deploy API and web over HTTPS.
8. Configure CORS to the production web origin.
9. Add transactional email provider before sending invitations/password reset emails.
10. Run end-to-end tests for signup, permissions, orders and payments.
