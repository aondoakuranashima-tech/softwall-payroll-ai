# Softmall production security baseline

Implemented:
- Helmet security middleware and security headers.
- Strict CORS allow-list from CORS_ORIGINS/APP_URL.
- Global DTO validation with whitelist + forbidNonWhitelisted.
- Request IDs.
- Rate limiting on sensitive endpoints (use Redis in multi-instance production).
- Email verification required before authenticated application access.
- Password reset no longer returns reset tokens.
- HSTS and browser security headers on the web app.
- Permissions-Policy disables camera, microphone and geolocation.
- Payment checkout endpoints rate-limited.

Required before launch:
- Run behind HTTPS and a trusted reverse proxy.
- Put PostgreSQL, Redis and secrets in managed infrastructure.
- Replace in-memory rate limiting with Redis.
- Configure transactional email for verification/reset/invites.
- Rotate JWT_SECRET and payment keys; never commit .env files.
- Add dependency scanning (npm audit/Snyk/GitHub Dependabot).
- Add centralized logs, alerting and error tracking.
- Add CSRF protection if authentication uses cookies.
- Add MFA for OWNER/ADMIN accounts.
- Verify Paystack/Stripe webhook signatures and make webhook handlers idempotent.
- Run penetration testing and backup/restore drills.
